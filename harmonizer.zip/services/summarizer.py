from ollama import Client
from typing import List, Dict

client = Client(host='http://localhost:11434')  # Local Ollama server

def summarize_controls(controls: List[Dict], model: str = "llama2") -> Dict:
    # Step 1: Build a smart prompt
    prompt = (
        "You are an expert in cybersecurity compliance. Given the following controls "
        "from different frameworks, generate a unified version with:\n"
        "1. A short merged title\n"
        "2. A clear, readable description\n"
        "3. Three implementation steps\n\n"
    )

    for c in controls:
        prompt += f"[{c['framework']}] {c['name']}: {c['description']}\n"

    # Step 2: Call Ollama locally
    response = client.generate(
        model=model,
        prompt=prompt,
        stream=False
    )

    # Step 3: Return raw text for now
    return {
        "prompt": prompt,
        "raw_summary": response['response'].strip()
    }
